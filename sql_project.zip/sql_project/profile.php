<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="profile.css">
</head>
<body>
    <header>
        <h1>User Profile</h1>
        <nav>
            <a href="tasks.php">Tasks</a>
            <a href="journal.php">Journal</a>
            <a href="index.html">Logout</a>
        </nav>
    </header>
    <main>
        <h2>Welcome to MY profile</h2>
        <p>This is the profile page. You can access your tasks or journal entries from the navigation menu.</p>
      
    </main>
    <footer>
        <p>&copy; Manpreet kaur</p>
    </footer>
</body>
</html>
