<?php
include 'DBConnection.php';

// Fetch tasks (since no session, tasks are general, not user-specific)
$query = "SELECT * FROM tasks";
$result = $conn->query($query);
$tasks = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Tasks</title>
    <link rel="stylesheet" href="tasks.css">
</head>
<body>
    <header>
        <h1>Your scsc Tasks</h1>
        <nav>
            <a href="profile.php">Profile</a>
            <a href="journal.php">Journal</a>
            <a href="index.html">Logout</a>
        </nav>
    </header>
    <main >
        <h2>Task List</h2>
        <form action="handleTask.php" method="POST">
            <label for="taskTitle">Task Title:</label>
            <input type="text" id="taskTitle" name="taskTitle" required>
            <input type="submit" value="Add Task">
        </form>

        <h3>Tasks:</h3>
        <ul>
            <?php foreach ($tasks as $task): ?>
                <li><?php echo htmlspecialchars($task['task_title']); ?> (Created on: <?php echo $task['created_at']; ?>)</li>
            <?php endforeach; ?>
        </ul>
    </main>
    <footer>
        <p>&copy; Manpreet kaur &copy;Lovepreet</p>
    </footer>
</body>
</html>
