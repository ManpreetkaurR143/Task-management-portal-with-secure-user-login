<?php
require 'DBConnection.php'; // Include your database connection


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['entryTitle'];
    $content = $_POST['entryContent'];

    // Prepare and execute the SQL query to insert into entry table
    $stmt = $conn->prepare("INSERT INTO entry (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);

    if ($stmt->execute()) {
        
        header("http://localhost/sql_project/journal.php");
        exit();
    } else {
        
        echo "Error: ".htmlspecialchars($stmt->error);
    }

    $stmt->close();
} 
else {
    
    header("Location: add_journal_entry.html");

    exit();
}

$conn->close();

?>