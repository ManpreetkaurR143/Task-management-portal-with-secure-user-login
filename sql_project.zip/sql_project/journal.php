<?php
require 'DBConnection.php';

// Fetch all journal entries
$query = "SELECT * FROM entry";
$result = $conn->query($query);

if ($result === false) {
    die("Error fetching entries: " . htmlspecialchars($conn->error)); // Handle query error
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Journal</title>
    <link rel="stylesheet" href="journal.css">
</head>
<body>
    <header>
        <h1>Your Journal</h1>
        <nav>
            <a href="profile.php">Profile</a>
            <a href="tasks.php">Tasks</a>
            <a href="index.html">Logout</a>
        </nav>
    </header>
    <main>
        <h2>Journal Entries</h2>
        <a href="add_journal_entry.html">Add New Entry</a>
        <br>
        
        <!-- Display journal entries -->
        <?php if ($result->num_rows > 0): ?>
            <ul>
                <?php while ($entry = $result->fetch_assoc()): ?>
                    <li>
                        <h3><?php echo htmlspecialchars($entry['title']); ?></h3>
                        <p><?php echo nl2br(htmlspecialchars($entry['content'])); ?></p>
                        <p><em>Created at: <?php echo htmlspecialchars($entry['created_at']); ?></em></p>
                    </li>
                    <br>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No journal entries found.</p>
        <?php endif; ?>
    </main>
    <footer>
        <p>&copy;Manpreet kaur</p>
    </footer>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
