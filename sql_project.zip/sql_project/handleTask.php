<?php
require 'DBConnection.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $taskTitle = $_POST['taskTitle'];

    
    if (empty($taskTitle)) {
        die("Error: Task title is missing.");
    }

    // Prepare and execute the SQL query to insert the task
    $query = "INSERT INTO tasks (task_title) VALUES (?)";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param("s", $taskTitle);
        if ($stmt->execute()) {
           
            header("Location: tasks.php");
            exit();
        } else {
            echo "Error executing query: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}
$conn->close();

echo"heelo";
?>